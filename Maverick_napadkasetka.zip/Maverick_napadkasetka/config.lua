Config = {}

Config.Reward = math.random(50, 9000)