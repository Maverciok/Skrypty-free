local playerCooldowns = {}

local kasetki = {}

ESX.RegisterServerCallback('dShopRobbery:checkPolice', function(source, cb, model)
    local players = ESX.GetPlayers()
    local police = 0 
    local currentTime = os.time() 
    local cooldown = 60 -- minuta
    local xPlayer = ESX.GetPlayerFromId(source)
    for i = 1, #players do 
        local policjant = ESX.GetPlayerFromId(players[i])
        if policjant.job.name == 'police' then
            police = police + 1
        end
    end 


    if police < 1 then return cb('nopolice') end 
    if kasetki[model] then return cb('again') end 


    if playerCooldowns[xPlayer.identifier] and (currentTime - playerCooldowns[xPlayer.identifier].lastRobbed) < cooldown then
        return cb('cooldown') 
    end 


    cb(police >= 1)
    sendToDiscord(wb, 66666, 'dShopRob', GetPlayerName(source)..' rozpoczął napad na kasetkę!')

end)



ESX.RegisterServerCallback('dShopRobbery:getReward', function(source, cb, model)
    local wb = 'https://discord.com/api/webhooks/1119019146009645177/DpH7pTl-GKyHlNlfi5x9QwDwfs0W2olx4Vg2rlp9wYWggSFK8zm-ochcev2vlt4DVNkQ'
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer then return end 
    local reward = Config.Reward 
    local currentTime = os.time() 
    kasetki[model] = true 
    playerCooldowns[xPlayer.identifier] = {
        lastRobbed = currentTime
    }
    xPlayer.addMoney(reward)
    cb(reward)
    sendToDiscord(wb, 66666, 'dShopRob', GetPlayerName(source)..' otrzymał z napadu na kasetkę '..reward..'$!')
end)



function sendToDiscord(webhook, color, name, message)
    local currentTime = os.date("%H:%M:%S") 
    local currentDate = os.date("%Y-%m-%d") 
    local embed = {
          {
              ["color"] = color,
              ["title"] = "**".. name .."**",
              ["description"] = message,
              ["footer"] = {
                  ["text"] = currentTime.." "..currentDate,
              },
          }
      }
    PerformHttpRequest(webhook, function(err, text, headers) end, 'POST', json.encode({username = name, embeds = embed}), { ['Content-Type'] = 'application/json' })
end