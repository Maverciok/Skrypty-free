local kasetki = {
    'prop_till_01',
    'prop_till_02',
    'prop_till_01_dam',
}

AddEventHandler('onResourceStart', function(resourceName)
    if (GetCurrentResourceName() == resourceName) then
        exports.qtarget:RemoveTargetModel(kasetki)
        exports.qtarget:AddTargetModel(kasetki, {
            options = {
                {
                    event = "dShopRobbery:startRobbery",
                    icon = "fas fa-sack-dollar",
                    label = "Obrabuj kasetkę!",
                    canInteract = function(entity)
                        if IsPedArmed(ESX.PlayerData.ped, 4) or IsPedArmed(ESX.PlayerData.ped, 1) then
                            return true
                        end
                        return false
                    end,
                },
            },
            distance = 1.5
        })
    end
end)





local isStealing = false

RegisterNetEvent('dShopRobbery:startRobbery', function(data)
    local entity = data.entity
    lib.hideTextUI()
    if data == nil or #(GetEntityCoords(ESX.PlayerData.ped) - GetEntityCoords(entity)) > data.distance then return TriggerEvent('dShopRobbery:notification', 'cheaterjebany_dShopRob', 'Błąd!', 'Coś poszło nie tak... \n\n Spróbuj podejść bliżej, jeśli to nie pomoże, skontaktuj się z developerem.', 'top', 7000) end
    local playerCoords = GetEntityCoords(ESX.PlayerData.ped)
    local playerRotation = GetEntityRotation(ESX.PlayerData.ped)
    local playerHeading = playerRotation.z
    local entityCoords = GetEntityCoords(entity)
    local entityRotation = GetEntityRotation(entity)
    local entityHeading = entityRotation.z

    local headingDiff = math.abs(playerHeading - entityHeading)
    if headingDiff > 90 and headingDiff < 270 then
        return TriggerEvent('dShopRobbery:notification', 'zly_kierunek_dShopRob', 'Błąd!', 'Stoisz z niewłaściwej strony kasy fiskalnej!', 'top', 5000)
    end
    if isStealing then return TriggerEvent('dShopRobbery:notification', 'juz_okradasz_kasetke_dShopRob', 'Błąd!', 'Już okradasz kasetkę!', 'top', 5000) end
    ESX.TriggerServerCallback('dShopRobbery:checkPolice', function(data1) 
        if data1 == 'nopolice' then return TriggerEvent('dShopRobbery:notification', 'brak_policji_dShopRob', 'Błąd!', 'Brak wystarczającej ilości PD na służbie', 'top', 5000) end
        if data1 == 'again' then return TriggerEvent('dShopRobbery:notification', 'znowu_ta_sama_kasetka_dShopRob', 'Błąd!', 'Nie możesz ponownie okraść tej kasetki!', 'top', 5000) end
        if data1 == 'cooldown' then return TriggerEvent('dShopRobbery:notification', 'wez_odczekaj_troche_dShopRob', 'Błąd!', 'Odczekaj jakiś czas zanim znowu okradniesz kasetke!', 'top', 5000) end
        if data1 == true then 
            
            isStealing = true
            lib.showTextUI('Wciśnij **X** aby anulować okradanie kasetki!', {
                position = "left-center",
                icon = 'xmark',
                iconColor = '#b08ab4',
                style = {
                    borderRadius = 0,
                    backgroundColor = '#141517',
                    color = 'white'
                }
            })
            --TriggerServerEvent('gpt:makeCall', '10-31b', "Napad na kasę fiskalną")
            if lib.progressBar({
                duration = 45000,
                label = 'Okradasz kasetkę!',
                useWhileDead = false,
                canCancel = true,
                disable = {
                    car = true,
                    combat = true,
                    move = true,
                },
                anim = {
                    dict = 'oddjobs@shop_robbery@rob_till',
                    clip = 'loop'
                },
            })
            then 
                ESX.TriggerServerCallback('dShopRobbery:getReward', function(reward)
                    isStealing = false
                    TriggerEvent('dShopRobbery:notification', 'nagroda_za_kasetke_dShopRob', 'Udało się!', 'Z rabunku otrzymałeś '..reward..'$', 'top', 5000)
                    lib.hideTextUI()
                end, entity)
            else
                isStealing = false 
                TriggerEvent('dShopRobbery:notification', 'kasetka_niepowodzenie_anulowana_dShopRob', 'Niepowodzenie!', 'Anulowałeś okradanie kasetki!', 'top', 5000)
                lib.hideTextUI()
            end
        end
    end, entity)
end)





RegisterNetEvent('dShopRobbery:notification', function(id, title, msg, pos, duration)
    lib.notify({
        id = id,
        title = title,
        description = msg,
        position = pos,
        duration = duration,
        style = {
            backgroundColor = '#141517',
            color = '#C1C2C5',
        },
        icon = 'xmark',
        iconColor = '#b08ab4'
    })
end)
